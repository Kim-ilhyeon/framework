package com.kh.spring.notice.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.spring.common.PageInfo;
import com.kh.spring.notice.model.dao.NoticeDao;
import com.kh.spring.notice.model.vo.Notice;

@Service		// @Compnent 보다 좀 더 구체화된 객체를 의미! => Service bean 등록
public class NoticeServiceImpl implements NoticeService {
	
	private final NoticeDao nDao;
	@Autowired
	public NoticeServiceImpl(NoticeDao nDao) {
		this.nDao = nDao;
	}

	@Override
	// 페이징 처리 적용 전
//	public ArrayList<Notice> selectNoticeList() {
//
//		ArrayList list = nDao.selectNoticeList();
//		
//		return list;
//	}
	// 페이징 처리 적용 후
	public ArrayList<Notice> selectNoticeList(PageInfo pi) {

		ArrayList list = nDao.selectNoticeList(pi);
		
		return list;
	}
	

	@Override
	public ArrayList<Notice> searchNoticeListByTitle(String keyword, PageInfo pi) {

		ArrayList list = (ArrayList<Notice>)nDao.findByNoticeTitleLike(keyword, pi);
		
		return list;
	}

	@Override
	public int selectNoticeCount() {
		
		int result = nDao.selectNoticeCount();
		return result;
	}
	
	@Override
	public int selectByNoticeTitleCount(String keyword) {
		
		int result = nDao.selectByNoticeTitleCount(keyword);
		return result;
	}

	@Override
	public Notice selectNoticeDetail(int noticeNo) {

		Notice notice = nDao.selectNotice(noticeNo);
		
		return notice;
	}

	@Override
	public int insertNotice(Notice notice) {
		int result = nDao.insertNotice(notice);
		return result;
	}

	@Override
	public int updateNotice(Notice notice) {
		int result = nDao.updateNotice(notice);
		return result;
	}

	@Override
	public int deleteNotice(int noticeNo) {
		int result = nDao.deleteNotice(noticeNo);
		System.out.println("서비스에서의 no : " + noticeNo);
		return result;
	}


	
	
}
