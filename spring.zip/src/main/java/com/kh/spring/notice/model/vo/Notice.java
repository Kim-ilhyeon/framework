package com.kh.spring.notice.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor	// 기본생성자
@AllArgsConstructor	// 모든 필드를 매개변수로 가지는 생성자

@Data	// 밑에 있는 3개의 어노테이션을 모두 합쳐진 어노테이션
//@Getter				// getter()
//@Setter				// setter()
//@ToString			// toString()

public class Notice {

	private int noticeNo;
	private String noticeTitle;
	private String noticeWriter;
	private String noticeContent;
	private String createDate;
	
	
	
}
