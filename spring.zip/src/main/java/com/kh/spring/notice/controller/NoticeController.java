package com.kh.spring.notice.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kh.spring.common.PageInfo;
import com.kh.spring.notice.model.vo.Notice;
import com.kh.spring.notice.service.NoticeService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/notice")
public class NoticeController {
	
	// NoticeService 객체를 생성자 주입방식(DI)으로 추가
	private final NoticeService nService;
	
	@Autowired	// 생략도 가능
	public NoticeController (NoticeService nService) {
		this.nService = nService;

	}
	
	
	// ----------------------------------
	
	/**
	 * 게시글 목록 페이지 응답 (요청 받는 주소 : /notice/list)
	 */
	@GetMapping("/list")
	public ModelAndView noticeListPage(String keyword, @RequestParam(value="cpage", defaultValue="1")int currPage, ModelAndView mv) {
//		System.out.println("get요청 들어옴@@");
		
		/* 페이징 처리를 위한 추가 작업 */
		// [1] 전체 게시글 수 조회
		int listCount = nService.selectByNoticeTitleCount(keyword);
		// => keyword 값이 null일 경우(전달되지 않았을 경우), 전체 게시글 수를 카운트 할 것임!!
		
		// [2] 현재 페이지 번호 --> 요청 시 전달되어야 하는 값
		
		// [3] 페이징 바 개수, 한 페이지 당 표시할 개수 --> 내가 지정하면 됨
		int pageLimit = 10;		// 페이징 바의 개수
		int boardLimit = 10;	// 한 페이지 당 표시할 게시글 개수
		
		PageInfo pi = new PageInfo(listCount, currPage, pageLimit, boardLimit);
		
		// * 페이징 바 정보를 request 영역에 저장 --> 페이징 바 표시할 때 사용할 것임!
		mv.addObject("pi", pi);
		
		// 응답 전 DB에서 공지사항 목록 조회
		// ArrayList<Notice> list = nService.selectNoticeList(pi);
		ArrayList<Notice> list = nService.searchNoticeListByTitle(keyword, pi);
		
		// request 영역에 조회된 목록을 저장 => Model
		// ModelAndView : 스프링에서 제공해주는 객체
		// - Model : 데이터를 key-value 형태로 저장할 수 있는 공간 (단독사용)
		// - View  : 응답 페이지에 대한 정보를 저장할 수 있는 공간 (단독사용X => ModelAndView 사용)
		mv.addObject("list", list);
		
		// * 검색 키워드(keyword)를 request 영역에 저장
		mv.addObject("keyword", keyword);
		
		// 공지사항 목록 페이지 요청
//		return "notice/noticeList";
		mv.setViewName("notice/noticeList");
		// serViewName() => 매개변수로 응답 페이지 정보를 주면 해당 페이지를 찾아서 응답을 해준다.
		
		return mv;
	}
	
	/**
	 * 제목으로 검색하여 게시글 목록 페이지 응답 (요청 받는 주소 : /notice/search)
	 */
	@GetMapping("/search")
	public String searchNoticeListByTitle(String keyword, @RequestParam(value="cpage", defaultValue="1") int currPage, Model model) {
//		System.out.println("Get요청 들어옴@@");
		
		// * PageInfo 객체 생성
		int listCount = nService.selectByNoticeTitleCount(keyword);
		int pageLimit = 10;
		int boardLimit = 10;
		
		PageInfo pi = new PageInfo (listCount, currPage, pageLimit, boardLimit);
		
		// * 조회된 목록을 request 영역에 "list" 키 값으로 저장
		ArrayList<Notice> list = nService.searchNoticeListByTitle(keyword, pi);
		model.addAttribute("list", list);
		
		// * 페이징 바 표시를 위해 request 영역에 "pi"키 값으로 PageInfo 저장
		model.addAttribute("pi", pi);
		String pis = pi.toString();
//		System.out.println("noticeController에서 pis " + pis);
		return "notice/noticeList";
		
	}
	
	
	/**
	 * 게시글 상세 페이지 응답 (요청 받는 주소 : /notice/detail)
	 * @param noticeNo
	 * @param model
	 * @return
	 */
	@GetMapping("/detail")
	public String noticeDetailPage(@RequestParam(value="no", defaultValue="0") int noticeNo, Model model) {
		
		// 글 번호에 해당하는 공지사항 정보 (글번호, 제목, 작성자, 내용, 작성일)
		Notice notice = nService.selectNoticeDetail(noticeNo);
		
		// request 영역에 저장 => Model 객체 사용
		model.addAttribute("notice", notice);
		
		// 상세 페이지 응답
		return "notice/noticeDetail";
		
	}
	
	/**
	 * 공지사항 작성페이지 응답 (요청 받는 주소 : /notice/enrollForm)
	 * 		=> WEB-INF/views/notice/enrollForm.jsp
	 * @return
	 */
	@GetMapping("/enrollForm")
	public String noticeUpdatePage() {
		return "notice/enrollForm";
	}
	
	
	/**
	 * 공지사항 등록 후 다시 목록 페이지로 재응답 (요청 받는 주소 : /notice/enrollForm)
	 * 		=> WEB-INF/views/notice/enrollForm.jsp
	 * + 성공 시 공지사항 목록 페이지로 url 재요청
	 * + 실패 시 에러페이지로 응드
	 */
	@PostMapping("/writer")
	public String insertNotice(Notice n, Model model) {
		
		int result = nService.insertNotice(n);
		
		if (result > 0) {
			// 공지사항 등록 성공!
			return "redirect:/notice/list";			
		} else {
			// 공지사항 등록 실패
			model.addAttribute("errorMsg", "공지사항을 등록하지 못하였습니다.");
			
			return "common/errorPage";
		}	
	}
	
	
	/**
	 * 공지사항 수정 페이지 응답 (요청 받는 주소 : notice/updateForm)
	 * 	?no = 공지사항 번호
	 * 		=> WEB-INF/views/notice/updateForm.jsp
	 */
	@GetMapping("/updateForm")
	public String updateForm(@RequestParam(value="no", defaultValue="0") int no, Model model) {
		// * 공지사항 번호에 해당하는 정보를 조회
//		System.out.println(no);	// => 매개변수'no'가 잘 전달되었는지 확인
		Notice notice = nService.selectNoticeDetail(no);
//		System.out.println("notice" + notice);
		
		// * 공지사항 데이터를 저장 (request scope)
		model.addAttribute("n", notice);
		
		// * 공지사항 수정페이지 응답			
		return "notice/updateForm";
	}
	
	
	/**
	 * 공지사항 수정 요청 (요청 받는 주소 : /notice/Detail)
	 * 			=> WEB-INF/views/notice/Detail.jsp
	 */
	@PostMapping("/update")
	public String updateNotice(@RequestParam(value="noticeNo", defaultValue="0")int no, Notice n, Model model) {
		
//		System.out.println("수정버튼 이후 no : " + no);
//		System.out.println("수정버튼 이후 n : " + n);
		// => 전달받은 매개변수가 정확한지 확인***
		
		// * 전달받은 공지사항의 정보를 변경
		int result = nService.updateNotice(n);
		System.out.println("noticeController에서의 result : " + result);
		if (result > 0) {
			// 수정성공	--> 해당 공지사항 상세페이지 표시
			// 				=> 상세페이지로 url 재요청
//			return "redirect:notice/detail?no=" + n.getNoticeNo();
			return "redirect:/notice/detail?no=" + no;
		} else {
			// 수정 실패 ㅠㅜ --> 에러페이지 표시
			model.addAttribute("errorMsg", "공지사항 수정 실패하였습니다.");
			return "common/errorPage";
		}	
	}
	
	/**
	 * 공지사항 삭제 요청 (요청 받는 주소 : /notice/delete
	 *  ?no = 공지사항 번호
	 */
	@GetMapping("/delete")
	public String deleteNotice(@RequestParam(defaultValue="0")int no, HttpSession session, Model model) {
		
		int result = nService.deleteNotice(no);
		
		if (result > 0) {
			// 삭제 성공 --> 공지사항 목록페이지로 응답 (url 재요청)
			return "redirect:/notice/list";
		} else {
			// 삭제 실패 --> 에러페이지로 응답
			model.addAttribute("errorMsg", "공지사항 삭제 실패 ㅠㅜ");
			return "common/errorPage";
		}	
	}
	
	
	
}
