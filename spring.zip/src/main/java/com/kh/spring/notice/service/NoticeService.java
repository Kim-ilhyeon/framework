package com.kh.spring.notice.service;

import java.util.ArrayList;

import com.kh.spring.common.PageInfo;
import com.kh.spring.notice.model.vo.Notice;

public interface NoticeService {

	/* 공지사항 목록 조회 DQL(SELECT) */
//	ArrayList<Notice> selectNoticeList();	// => 추상메소드이기 떄문에 <>필요없음	=> 페이징 처리 적용 전
	ArrayList<Notice> selectNoticeList(PageInfo pi);					 // => 페이징 처리 적용 후 
	
	/* 공지사항 상세 조회 DQL(SELECT) */
	Notice selectNoticeDetail(int noticeNo);
	
	/* 공지사항 제목 검색 DQL(SELECT) */
	ArrayList<Notice> searchNoticeListByTitle(String keyword, PageInfo pi);

	/* 공지사항 전체 게시글 수 조회 DQL(SELECT) */
	int selectNoticeCount();
	
	/* 공지사항 검색한 게시글 수 조회 DQL(SELECT) */
	int selectByNoticeTitleCount(String keyword);
	
	/* 공지사항 추가 DML(INSERT) */
	int insertNotice(Notice notice);
	
	/* 공지사항 추가 DML(UPDATE) */
	int updateNotice(Notice notice);
	
	/* 공지사항 삭제 DML(UPDATE) */
	int deleteNotice(int noticeNo);

	
}
