package com.kh.spring.member.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.spring.member.model.vo.Member;
import com.kh.spring.member.service.MemberService;

import jakarta.servlet.http.HttpSession;

@Controller		// Controller 어노테이션 추가 시 빈 스캐닝을 통해 자동으로 등록이 빈 등록이 된다.
@RequestMapping("/member")	// 공통 주소를 설정 => 해당 클래스에서 받는 요청은 /member로 시작될 것임!!
public class MemberController {
	
	/*
	 * * 기존 객체 생성 방식
	 * 
	 * 	private MemberService mService = new MemberServiceImpl();
	 * 
	 * => 객체 간의 결합도가 높아짐 (-> 코드 수정 시 각각 모두 바꿔줘야 함)
	 * => 동시에 많은 요청이 될 경우 그만큼 객체가 생성될 것임!
	 * 
	 * 
	 * * DI (Dependency Injection) - 의존성 주입
	 * 
	 * 		@Autowired : 의존성 주입 시 사용되는 어노테이션
	 * 
	 * 		=> 클래스 내에 객체를 직접 생성하지 않고, spring에서 관리하는 객체를 주입받아서(bean을 등록) 사용하도록 해줄 것임!
	 * 
	 * 		[주입방식]
	 * 		1) 필드 주입 방식
	 * 		  : 스프링 컨테이너가 객체를 생성한 후 @Autowired가 붙은 필드에 의존성을 주입하는 방식
	 * 		장점 => 간결하고 해당 필드에 대한 처리를 따로 하지않아도 됨. (생성자, setter)	
	 * 		단점 => 테스트가 어려움
	 * 			(객체 생성 시 주입되는 것이 아닌 bean에 생성된 후 주입받는 방식으로 테스트 진행 시 임의의 객체를 생성하기가 어렵다.)
	 * 		   불변성 보장 문제
	 * 			(객체 생성 시 의존성이 주입되어 고정되지 않으므로 클래스 생성 이후 의존성이 변경될 수 있음)
	 * 
	 * 		2) 생성자 주입 방식
	 * 		  : 스프링 컨테이너가 객체를 생성할 때에 @Autowired가 붙은 생성자를 통해 필요한 의존성을 주입하는 방식
	 * 		장점 => 불변성이 보장되고, 테스트가 편리함, 순환 참조 방지
	 */
	/* 필드 주입 방식 */
	/*
	@Autowired
	private MemberService mService;
	*/
	
	/* 생성자 주입 방식 */
	private final MemberService mService;
	private final BCryptPasswordEncoder bCryptPasswordEncoder;
		
	@Autowired
	public MemberController (MemberService mService, BCryptPasswordEncoder bCryptPasswordEncoder) {
		this.mService = mService;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	// => 생성자 주입방식 --> lombok 기능으로 사용 가능
	// @RequiredArgsConstructor 클래스 위에 작성 후 import = 필드로 선언된 객체(baen)를 생성자 방식으로 주입기능
	
	
	//-----------------------------------------------------

	/**
	 * 회원가입 페이지 응답
	 */
//	@RequestMapping("/enrollForm")
	@GetMapping("/enrollForm")
	// RequestMapping / GetMapping은 요청된 주소경로가 위에 설정한 주소가 되면 밑에 파일경로의 페이지를 Client 에게 보여줌 => /member/enrollForm 이라고 header.jsp에서 get방식으로 요청
	
	public String enrollFormPage() {
		// => 응답할 페이지 정보(경로)
		//	  /WEB-INF/views/member/enrollForm.jsp
		// {prefix}member/enrollForm{suffix}
		// --> 설정값을 제외하고 문자열로 리턴하면 해당 파일을 찾아 응답할 것임!
		// 페이지의 파일경로?!임  url이랑은 다름 => 어디 파일에 있는지 경로
		return "member/enrollForm";
	}
	
	/**
	 * [1] HttpServletRequest 객체 이용 (기존 서블릿 방법)
	 * 		=> 매개변수 위치에 HttpServletRequest 타입을 작성!
	 * @return
	 */
	/*
	@PostMapping("/regist")
	public String registMember(HttpServletRequest request) {
		// 아이디, 비밀번호 데이터를 추출하여 출력해보자
		System.out.println("회원가입 요청이 들어옴");
		
		String userId = request.getParameter("userId");
		String userPwd = request.getParameter("userPwd");
		String userName = request.getParameter("userName");
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		String age = request.getParameter("age");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String enrollDate = request.getParameter("enrollDate");
		String modifyDate = request.getParameter("modifyDate");
		String status = request.getParameter("status");
		
		System.out.printf("%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, ", 
								userId, userPwd, userName, email, gender, age, phone, address, enrollDate, modifyDate, status);
		
		
		// 회원가입 페이지 응답 (임시)
		return "member/enrollForm";
	}
	*/
	
	/**
	 * [2] ReqeustParam 어노테이션 이용
	 * 		=> @RequestParam("키값") 자료형 변수명 --> 매개변수 위치에 작성
	 * 
	 * 		   @RequestParam(value=:"키값", defaultValue="기본값")
	 * 
	 * 		request.getParameter("키값") --> 데이터를 추출
	 * 		위의 작업을 대신해주는 어노테이션이다.
	 */
	/*
	@PostMapping("/regist")
	public String registMember(@RequestParam("userId") String id, 
								@RequestParam("userPwd") String pwd) {
		
		System.out.println("id : " + id);
		System.out.println("password : " + pwd);
		
		return "member/enrollForm";
		
	}
	*/
	
	
	
	
	/**
	 * [3] @RequestParam 생략
	 * 		=> 주의!! 매개변수명을 요청 시 전달되는 데이터의 키값과 동일하게 작성해야 함!!
	 */
	/*
	@PostMapping("/regist")
	public String registMember(String userId, String userPwd) {
		
		System.out.println("id : " + userId);
		System.out.println("password : " + userPwd);
		
		return "member/enrollForm";
		
	}
	*/
	
	/**
	 * [4] 커맨트 객체 방식
	 * 		=> 요청 시 전달되는 데이터를 VO/DTO 클래스 타입으로 받고자 하는 경우
	 * 
	 * 		* 매개변수 타입을 VO/DTO 클래스 타입으로 작성
	 * 		  !!주의!! 전달되는 데이터의 키값을 받고자 하는 클래스의 "필드명"과 "일치"하도록 해야함!!
	 * 
	 * 		* 스프링 컨테이너가 해당 클래스 객체를 "기본생성자"로 생성 후
	 * 		  setter 메소드를 사용하여 요청 시 전달 값을 해당 필드에 저장함
	 */
	
	@PostMapping("/regist")
	public String registMember(Member user, HttpSession session, Model model) {
		
//		System.out.println(user);
		
		// -> 처리 전 : 비밀번호는 평문(입력한 값 그대로)
		// 비밀번호 암호화 처리 => BCryptPasswordEncoder
		
		System.out.println("memberController에서의 user.getUserPwd() " + user.getUserPwd());
		
		String encPwd = bCryptPasswordEncoder.encode(user.getUserPwd());
		
		System.out.println("memberController 에서의 encPwd " + encPwd);
		
		user.setUserPwd(encPwd);
		// -> 처리 후 : 비밀번호는 암호문(암호화 처리된 값)
		
		// 서비스에게 Member 객체를 전달하여 회원가입 요청
		int result = mService.insertMember(user);
		
		// 결과에 따른 처리
		if (result > 0) {	// 회원가입 성공
			// "회원가입에 성공했습니다. 환영합니다^^" 메세지 저장
			session.setAttribute("alertMsg", "회원가입에 성공했습니다. 환영합니다.^^");
			// 메인페이지로 url 재요청
			return "redirect:/";		// "redirect:요청할url주소"
		} else {			// 회원가입 실패
			// "회원가입에 실패했습니다." 메세지 저장
			// --> request 영역에 저장 => Model 객체
			model.addAttribute("errorMsg", "회원가입에 실패했습니다.");
			
			// 에러페이지 응답
			// return "WEB-INF/views/common/errorPage.jsp";
			return "common/errorPage";
		}
		
//		 return "member/enrollForm";
		 // Unreachable code --> 이미 위에서 처리가 되어있을때 보이는 오류내용
		
	}
	
	/**
	 * 로그인 요청
	 * @param user
	 * @param session
	 * @param model
	 * @return
	 */
	@PostMapping("/login")		// 사실상 /member/login 요청 받을 것임!
	public String login(Member user, HttpSession session, Model model) { // @ModelAttribute Member user와 같이 작성할 수 있음!
		
//		System.out.println(user);	// => Controller가 잘 전달받았는지 확인
		
		// 서비스에게 Member 객체를 전달하여 로그인 요청
		Member loginUser = mService.loginMember(user);
		/*
		 * user => 사용자가 입력한 값을 저장 (요청 시 전달된 데이터) 	[평문]
		 * loginUser => DB에서 아이디 기준으로 조회한 데이터 		[암호문]
		 */
		
		// 결과에 따른 처리
		if (loginUser == null) {
			// 아이디에 해당하는 회원정보가 없을 경우
			model.addAttribute("errorMsg", "아이디에 해당하는 회원 정보가 없습니다.");
			return "common/errorPage";
		} else if ( !bCryptPasswordEncoder.matches( user.getUserPwd()/*평문*/, loginUser.getUserPwd()/*암호문*/) ) {
			// 입력된 비밀번호 값이 저장된 비밀번호에 해당하지 않는 경우
			model.addAttribute("errorMsg", "비밀번호가 잘못 입력되었습니다.");
			return "common/errorPage";
		} else {
			// 로그인 성공
			session.setAttribute("alertMsg", "로그인 성공!!");
			session.setAttribute("loginUser", loginUser);
			return "redirect:/";
		}
		
		/*
		if (loginUser != null) {	// 입력한 아이디와 비밀번호가 있을 경우 (로그인 성공)
			// "로그인 성공하였습니다.!!" 메세지 저장
			session.setAttribute("alertMsg", "로그인 성공하였습니다.!!");
			
			// 로그인 정보를 session 영역에 저장
			session.setAttribute("loginUser", loginUser);
			// 메인페이지로 url 재요청
					// --> 데이터를 저장해야 한다면 "session" 영역에 저장!
			return "redirect:/";
		} else {				// 입력한 아이디와 비밀번호가 없을 경우 (로그인 실패)
			// "입력하신 아이디나 비밀번호가 틀렸습니다.." 메세지 저장
			// --> request 영역에 저장 => Model 객체
			model.addAttribute("errorMsg", "입력하신 아이디나 비밀번호가 틀렸습니다..");
			// 에러페이지 응답 (포워딩)
			return "common/errorPage";
		}
		*/

		
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		
//		session.removeAttribute("loginUser");	// session 영역의 loginUser에 대한 값을 삭제
		session.invalidate();					// session 영역을 비우기
		// 위에 두개 중 하나선택하여 사용
		
//		System.out.println("요청 들어옴!!!!");
		
		// 메인페이지로 url 재요청
		return "redirect:/";
		
	}
	
	@GetMapping("/myPage")
	public String myPage() {
		
		
		return "member/myPage";
		
	}
	
	@PostMapping("/update")
	public String updateMember(Member user, HttpSession session, Model model) {
		
		Member updateUser = mService.updateMember(user);
		
		if (updateUser != null) {  // 회원정보 수정 성공!!
			session.setAttribute("alertMsg", "회원정보가 정상적으로 수정되었습니다.");
			session.removeAttribute("loginUser");
			return "redirect:/";
		} else {					// 회원정보 수정 실패ㅠㅠ
			model.addAttribute("errorMsg", "정보수정을 실패했습니다.");
			return "../common/errorPage";
		}
		
		
	}

	
	
}
