package com.kh.spring.member.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.spring.member.model.dao.MemberDao;
import com.kh.spring.member.model.vo.Member;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor	// 필드로 선언된 객체(baen)를 생성자 방식으로 주입기능
@Service		// @Compnent 보다 좀 더 구체화된 객체를 의미! => Service bean 등록
public class MemberServiceImpl implements MemberService {
	
	/*
	 * **MemberDao 객체에 대한 DI 처리**
	 */
	@Autowired
	private final MemberDao mDao;
	/*
	@Autowired
	public MemberServiceImpl (MemberDao mDao) {
		this.mDao = mDao;
	}
	// => 생성자 주입방식 --> lombok 기능 사용으로 주석처리
	*/
	
	

	@Override
	public int insertMember(Member m) {
		
		int result = mDao.insertMember(m);
		
		return result;
	}

	@Override
	public Member loginMember(Member m) {
		
		Member loginUser = mDao.loginMember(m);
		
		return loginUser;
	}

	@Override
	public Member updateMember(Member m) {

		// 회원정보 수정
		int updateUser = mDao.updateMember(m);
		
		// 수정 성공 시 회원정보 조회
		if (updateUser > 0) {
			Member selectUser = mDao.loginMember(m);			
			return selectUser;
		}
		return null;
	}

	@Override
	public int deleteMember(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}
