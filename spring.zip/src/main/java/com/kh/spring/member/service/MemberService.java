package com.kh.spring.member.service;

import com.kh.spring.member.model.vo.Member;

public interface MemberService {

	/* (C)회원 가입 서비스 */
	int insertMember (Member m);
	
	/* (R)로그인 서비스 */
	Member loginMember (Member m);
	
	/* (U)회원정보 수정 서비스 */
	Member updateMember (Member m);
	
	/* (D)회원정보 삭제 서비스 */
	int deleteMember (String id);
	
}
