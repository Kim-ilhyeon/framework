package com.kh.spring.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.kh.spring.interceptor.LoginInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		
//		System.out.println("@@@@@@@@@@@@@");
		// 인터셉터를 등록
		// * LoginInterceptor
		registry.addInterceptor(new LoginInterceptor())
//				.addPathPatterns("/member/myPage", "/board/enrollForm");
				.addPathPatterns("/member/mypage", "/notice/**", "/board/**")
				.excludePathPatterns("/notice/list", "/board/list");		// * 인터셉터를 적용하지 않을 url
	}

	
}
